﻿Public Class Calender

    Private Sub calback_Click(sender As Object, e As EventArgs)
        MDbrowser.Show()

    End Sub

    Private Sub Calender_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
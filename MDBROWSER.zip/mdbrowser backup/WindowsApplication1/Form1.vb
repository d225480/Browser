﻿Public Class MDbrowser

    'command buttons

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles cmdgo.Click
        frawebbrowser.Navigate(txtaddress.Text)
    End Sub

    Private Sub cmdback_Click(sender As Object, e As EventArgs) Handles cmdback.Click
        frawebbrowser.GoBack()
    End Sub

    Private Sub cmdforward_Click(sender As Object, e As EventArgs) Handles cmdforward.Click
        frawebbrowser.GoForward()

    End Sub

    Private Sub cmdhome_Click(sender As Object, e As EventArgs) Handles cmdhome.Click
        frawebbrowser.GoHome()

    End Sub


    Private Sub cmdstop_Click(sender As Object, e As EventArgs) Handles cmdstop.Click
        frawebbrowser.Stop()
    End Sub

    Private Sub cmdrefresh_Click(sender As Object, e As EventArgs) Handles cmdrefresh.Click
        frawebbrowser.Refresh()
    End Sub
    Private Sub cmdsearch_Click(sender As Object, e As EventArgs) Handles cmdsearch.Click
        If optfacebook.Checked Then
            frawebbrowser.Navigate("https://nl-nl.facebook.com/")
        ElseIf optgoogle.Checked Then
            frawebbrowser.Navigate("https://www.google.nl/webhp?ei=KZbZV8vHOsOqU4egi5gK&emsg=NCSR&noj=" & txtsearch.Text & "&oq=" & txtsearch.Text)
        ElseIf opttwitter.Checked Then
            frawebbrowser.Navigate("https://twitter.com/")
        ElseIf optyoutube.Checked Then
            frawebbrowser.Navigate("https://www.youtube.com/results?search_query=" & txtsearch.Text & "&oq=" & txtsearch.Text)

        Else
            optgoogle.Checked = True
            frawebbrowser.Navigate("https://www.google.nl/webhp?ei=KZbZV8vHOsOqU4egi5gK&emsg=NCSR&noj=" & txtsearch.Text & "&oq=" & txtsearch.Text)
        End If

    End Sub
    'mnuedit

    Private Sub mnueditgo_Click(sender As Object, e As EventArgs) Handles mnueditgo.Click
        frawebbrowser.Navigate(txtaddress.Text)
    End Sub

    Private Sub mnueditback_Click(sender As Object, e As EventArgs) Handles mnueditback.Click
        frawebbrowser.GoBack()
    End Sub

    Private Sub mnueditforward_Click(sender As Object, e As EventArgs) Handles mnueditforward.Click
        frawebbrowser.GoForward()
    End Sub

    Private Sub mnuedithome_Click(sender As Object, e As EventArgs) Handles mnuedithome.Click
        frawebbrowser.GoHome()
    End Sub

    Private Sub mnueditrefresh_Click(sender As Object, e As EventArgs) Handles mnueditrefresh.Click
        frawebbrowser.Refresh()
    End Sub

    Private Sub mnueditstop_Click(sender As Object, e As EventArgs) Handles mnueditstop.Click
        frawebbrowser.Stop()
    End Sub
    Private Sub mnueditcut_Click(sender As Object, e As EventArgs) Handles mnueditcut.Click
        If txtaddress.Focused And txtaddress.SelectedText <> "" Then
            Clipboard.SetText(txtaddress.SelectedText)
            txtaddress.SelectedText = ""
        End If
        If txtsearch.Focused And txtsearch.SelectedText <> "" Then
            Clipboard.SetText(txtaddress.SelectedText)
            txtaddress.SelectedText = ""
        End If
        If frawebbrowser.Focused Then
            frawebbrowser.Document.ExecCommand("cut", False, vbNull)
        End If
    End Sub

    Private Sub mnueditcopy_Click(sender As Object, e As EventArgs) Handles mnueditcopy.Click
        If txtaddress.Focused And txtaddress.SelectedText <> "" Then
            Clipboard.SetText(txtaddress.SelectedText)
        End If
        If txtsearch.Focused And txtsearch.SelectedText <> "" Then
            Clipboard.SetText(txtsearch.SelectedText)
        End If
        If frawebbrowser.Focused Then
            frawebbrowser.Document.ExecCommand("copy", False, vbNull)
        End If
    End Sub

    Private Sub mnueditpaste_Click(sender As Object, e As EventArgs) Handles mnueditpaste.Click
        If txtaddress.Focused Then
            txtaddress.Text = Clipboard.GetText()
        End If
        If txtsearch.Focused Then
            txtsearch.Text = Clipboard.GetText()
        End If
        If frawebbrowser.Focused Then
            frawebbrowser.Document.ExecCommand("paste", False, vbNull)
        End If
    End Sub
    'mnufile
    Private Sub mnufileprint_Click(sender As Object, e As EventArgs) Handles mnufileprint.Click
        frawebbrowser.Print()
    End Sub

    Private Sub mnufileprintpreview_Click(sender As Object, e As EventArgs) Handles mnufileprintpreview.Click
        frawebbrowser.ShowPrintPreviewDialog()
    End Sub

    Private Sub mnufileproperties_Click(sender As Object, e As EventArgs) Handles mnufileproperties.Click
        frawebbrowser.ShowPropertiesDialog()
    End Sub

    Private Sub mnufileexit_Click(sender As Object, e As EventArgs) Handles mnufileexit.Click
        Me.Close()
    End Sub
    'url balk
    Private Sub txtaddress_KeyDown_enter(sender As Object, e As KeyEventArgs) Handles txtaddress.KeyDown
        If e.KeyCode = Keys.Enter Then
            cmdgo.PerformClick()
        End If
    End Sub

    Private Sub txtsearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtsearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            cmdsearch.PerformClick()

        End If
    End Sub
    Public InvalidOperationException()
    'status 
    Private Sub TimerURL_Tick(sender As Object, e As EventArgs) Handles TimerURL.Tick
        If frawebbrowser.StatusText = "sluiten" Then lbladdress.Text = "ready" Else lbladdress.Text = frawebbrowser.StatusText

    End Sub
    Private Sub frawebbrowser_progresschanged(sender As Object, e As WebBrowserProgressChangedEventArgs) Handles frawebbrowser.ProgressChanged
        Dim curprogress, maxprogress As Single
        curprogress = e.CurrentProgress
        maxprogress = e.MaximumProgress
        If curprogress <= 0 Then
            comprogressbar.Value = 0
            comprogressbar.Visible = False
        Else
            comprogressbar.Visible = True
            comprogressbar.Value = Math.Min(comprogressbar.Maximum, Convert.ToInt32(Math.Floor(comprogressbar.Maximum * (curprogress / maxprogress))))
        End If
    End Sub
    Private Sub frawebbrowser_documentcompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles frawebbrowser.DocumentCompleted
        txtaddress.Text = frawebbrowser.Url.ToString()
        Me.Text = "md browser | " & frawebbrowser.DocumentTitle
        stastrip.Visible = True
        comprogressbar.Value = 0
        comprogressbar.Visible = True
    End Sub
    'my renderer and colors and menu theme
    Public Class myrenderer : Inherits ToolStripProfessionalRenderer

        Protected Overrides Sub onrenderseparator(e As ToolStripSeparatorRenderEventArgs)
            If e.Vertical OrElse TryCast(e.Item, ToolStripSeparator) Is Nothing Then
                MyBase.OnRenderSeparator(e)
            Else
                Dim tsbounds As Rectangle = New Rectangle(Point.Empty, e.Item.Size)
                e.Graphics.FillRectangle(New SolidBrush(Color.Black), tsbounds)

                Dim lineY As Integer = tsbounds.Bottom - (tsbounds.Height / 2) - 1
                Dim lineleft As Integer = tsbounds.Left + 30
                Dim lineright As Integer = tsbounds.Right - 3
                e.Graphics.DrawLine(New Pen(Brushes.White), lineleft, lineY, lineright, lineY)
            End If
        End Sub
        Protected Overrides Sub OnRenderMenuItemBackground(ByVal e As ToolStripItemRenderEventArgs)
            Dim mnurectangle As New Rectangle(Point.Empty, e.Item.Size)
            Dim themerood As Color
            If e.Item.Selected Then
                themerood = Color.Red
            Else
                themerood = Color.Black
            End If
            Using Brush As New SolidBrush(themerood)
                e.Graphics.FillRectangle(Brush, mnurectangle)

            End Using
        End Sub
    End Class

    Private Sub mnuthemenormaal_Click(sender As Object, e As EventArgs) Handles mnuthemenormaal.Click
        Me.BackColor = Color.Empty
        Me.mnustrip.BackColor = Color.Empty


        Me.cmdgo.BackColor = Color.Transparent
        Me.optfacebook.ForeColor = Color.Empty
        Me.optgoogle.ForeColor = Color.Empty
        Me.opttwitter.ForeColor = Color.Empty
        Me.optyoutube.ForeColor = Color.Empty

        Me.mnufile.ForeColor = Color.Empty
        Me.mnufileprint.ForeColor = Color.Empty
        Me.mnufileprintpreview.ForeColor = Color.Empty
        Me.mnufileproperties.ForeColor = Color.Empty
        Me.mnufileexit.ForeColor = Color.Empty

        Me.mnuedit.ForeColor = Color.Empty
        Me.mnueditcut.ForeColor = Color.Empty
        Me.mnueditcopy.ForeColor = Color.Empty
        Me.mnueditpaste.ForeColor = Color.Empty
        Me.mnueditgo.ForeColor = Color.Empty
        Me.mnueditback.ForeColor = Color.Empty
        Me.mnueditforward.ForeColor = Color.Empty
        Me.mnuedithome.ForeColor = Color.Empty
        Me.mnueditrefresh.ForeColor = Color.Empty
        Me.mnueditstop.ForeColor = Color.Empty

        Me.mnuhelp.ForeColor = Color.Empty
        Me.mnuhelpover.ForeColor = Color.Empty

        Me.cmdgo.BackColor = Color.Transparent
        Me.cmdback.BackColor = Color.Transparent
        Me.cmdforward.BackColor = Color.Transparent
        Me.cmdhome.BackColor = Color.Transparent
        Me.cmdsearch.BackColor = Color.Transparent
        Me.cmdrefresh.BackColor = Color.Transparent
        Me.cmdstop.BackColor = Color.Transparent

        Me.cmdgo.ForeColor = Color.Empty
        Me.cmdback.ForeColor = Color.Empty
        Me.cmdforward.ForeColor = Color.Empty
        Me.cmdhome.ForeColor = Color.Empty
        Me.cmdsearch.ForeColor = Color.Empty
        Me.cmdrefresh.ForeColor = Color.Empty
        Me.cmdstop.ForeColor = Color.Empty
        Me.stastrip.ForeColor = Color.Empty
        Me.lbladdress.ForeColor = Color.Empty

        Me.stastrip.BackColor = Color.Empty
        Me.lbladdress.ForeColor = Color.Empty

        Me.mnutheme.ForeColor = Color.Black
        Me.mnuthemerood.ForeColor = Color.Black
        Me.mnuthemenormaal.ForeColor = Color.Black



    End Sub

    Private Sub mnuthemerood_Click(sender As Object, e As EventArgs) Handles mnuthemerood.Click

        Me.BackColor = Color.Black

        Me.mnustrip.BackColor = Color.Black

        Me.cmdgo.BackColor = Color.Red

        Me.optfacebook.ForeColor = Color.White
        Me.optgoogle.ForeColor = Color.White
        Me.opttwitter.ForeColor = Color.White
        Me.optyoutube.ForeColor = Color.White

        Me.mnufile.ForeColor = Color.White
        Me.mnufileprint.ForeColor = Color.Black
        Me.mnufileprintpreview.ForeColor = Color.Black
        Me.mnufileproperties.ForeColor = Color.Black
        Me.mnufileexit.ForeColor = Color.Black

        Me.mnuedit.ForeColor = Color.White
        Me.mnueditcut.ForeColor = Color.Black
        Me.mnueditcopy.ForeColor = Color.Black
        Me.mnueditpaste.ForeColor = Color.Black
        Me.mnueditgo.ForeColor = Color.Black
        Me.mnueditback.ForeColor = Color.Black
        Me.mnueditforward.ForeColor = Color.Black
        Me.mnuedithome.ForeColor = Color.Black
        Me.mnueditrefresh.ForeColor = Color.Black
        Me.mnueditstop.ForeColor = Color.Black

        Me.mnuhelp.ForeColor = Color.White
        Me.mnuhelpover.ForeColor = Color.Black

        Me.mnutheme.ForeColor = Color.White
        Me.mnuthemenormaal.ForeColor = Color.Black
        Me.mnuthemerood.ForeColor = Color.Black

        Me.cmdgo.BackColor = Color.Red
        Me.cmdback.BackColor = Color.Red
        Me.cmdforward.BackColor = Color.Red
        Me.cmdhome.BackColor = Color.Red
        Me.cmdsearch.BackColor = Color.Red
        Me.cmdrefresh.BackColor = Color.Red
        Me.cmdstop.BackColor = Color.Red

        Me.cmdgo.ForeColor = Color.Empty
        Me.cmdback.ForeColor = Color.Empty
        Me.cmdforward.ForeColor = Color.Empty
        Me.cmdhome.ForeColor = Color.Empty
        Me.cmdsearch.ForeColor = Color.Empty
        Me.cmdrefresh.ForeColor = Color.Empty
        Me.cmdstop.ForeColor = Color.Empty
        Me.stastrip.ForeColor = Color.Empty
        Me.lbladdress.ForeColor = Color.Empty

        Me.stastrip.BackColor = Color.Black
        Me.lbladdress.ForeColor = Color.White

        Me.mnutheme.ForeColor = Color.Black
        Me.mnuthemerood.ForeColor = Color.Black
        Me.mnuthemenormaal.ForeColor = Color.Black


    End Sub

    'about box
    Private Sub mnuhelpover_Click(sender As Object, e As EventArgs) Handles mnuhelpover.Click
        AboutBox1.Show()
    End Sub
End Class


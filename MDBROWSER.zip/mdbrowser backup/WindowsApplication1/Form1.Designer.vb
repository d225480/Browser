﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDbrowser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MDbrowser))
        Me.mnustrip = New System.Windows.Forms.MenuStrip()
        Me.mnufile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnufileprint = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnufileprintpreview = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnufileproperties = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnufileseparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnufileexit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuedit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnueditcut = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnueditcopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnueditpaste = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnueditgo = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnueditback = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnueditforward = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuedithome = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnueditrefresh = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnueditstop = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnutheme = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuthemenormaal = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuthemerood = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuhelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuhelpover = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtaddress = New System.Windows.Forms.TextBox()
        Me.cmdgo = New System.Windows.Forms.Button()
        Me.cmdhome = New System.Windows.Forms.Button()
        Me.cmdforward = New System.Windows.Forms.Button()
        Me.cmdback = New System.Windows.Forms.Button()
        Me.cmdsearch = New System.Windows.Forms.Button()
        Me.cmdstop = New System.Windows.Forms.Button()
        Me.cmdrefresh = New System.Windows.Forms.Button()
        Me.txtsearch = New System.Windows.Forms.TextBox()
        Me.optgoogle = New System.Windows.Forms.RadioButton()
        Me.optyoutube = New System.Windows.Forms.RadioButton()
        Me.optfacebook = New System.Windows.Forms.RadioButton()
        Me.opttwitter = New System.Windows.Forms.RadioButton()
        Me.stastrip = New System.Windows.Forms.StatusStrip()
        Me.lbladdress = New System.Windows.Forms.ToolStripStatusLabel()
        Me.comprogressbar = New System.Windows.Forms.ToolStripProgressBar()
        Me.frawebbrowser = New System.Windows.Forms.WebBrowser()
        Me.TimerURL = New System.Windows.Forms.Timer(Me.components)
        Me.mnustrip.SuspendLayout()
        Me.stastrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnustrip
        '
        Me.mnustrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnufile, Me.mnuedit, Me.mnutheme, Me.mnuhelp})
        Me.mnustrip.Location = New System.Drawing.Point(0, 0)
        Me.mnustrip.Name = "mnustrip"
        Me.mnustrip.Size = New System.Drawing.Size(1409, 28)
        Me.mnustrip.TabIndex = 0
        Me.mnustrip.Text = "MenuStrip1"
        '
        'mnufile
        '
        Me.mnufile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnufileprint, Me.mnufileprintpreview, Me.mnufileproperties, Me.mnufileseparator1, Me.mnufileexit})
        Me.mnufile.Name = "mnufile"
        Me.mnufile.Size = New System.Drawing.Size(42, 24)
        Me.mnufile.Text = "file"
        '
        'mnufileprint
        '
        Me.mnufileprint.Name = "mnufileprint"
        Me.mnufileprint.Size = New System.Drawing.Size(165, 24)
        Me.mnufileprint.Text = "print"
        '
        'mnufileprintpreview
        '
        Me.mnufileprintpreview.Name = "mnufileprintpreview"
        Me.mnufileprintpreview.Size = New System.Drawing.Size(165, 24)
        Me.mnufileprintpreview.Text = "print preview"
        '
        'mnufileproperties
        '
        Me.mnufileproperties.Name = "mnufileproperties"
        Me.mnufileproperties.Size = New System.Drawing.Size(165, 24)
        Me.mnufileproperties.Text = "properties"
        '
        'mnufileseparator1
        '
        Me.mnufileseparator1.Name = "mnufileseparator1"
        Me.mnufileseparator1.Size = New System.Drawing.Size(162, 6)
        '
        'mnufileexit
        '
        Me.mnufileexit.Name = "mnufileexit"
        Me.mnufileexit.Size = New System.Drawing.Size(165, 24)
        Me.mnufileexit.Text = "exit"
        '
        'mnuedit
        '
        Me.mnuedit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnueditcut, Me.mnueditcopy, Me.mnueditpaste, Me.mnueditgo, Me.mnueditback, Me.mnueditforward, Me.mnuedithome, Me.mnueditrefresh, Me.mnueditstop})
        Me.mnuedit.Name = "mnuedit"
        Me.mnuedit.Size = New System.Drawing.Size(47, 24)
        Me.mnuedit.Text = "edit"
        '
        'mnueditcut
        '
        Me.mnueditcut.Name = "mnueditcut"
        Me.mnueditcut.Size = New System.Drawing.Size(130, 24)
        Me.mnueditcut.Text = "cut"
        '
        'mnueditcopy
        '
        Me.mnueditcopy.Name = "mnueditcopy"
        Me.mnueditcopy.Size = New System.Drawing.Size(130, 24)
        Me.mnueditcopy.Text = "copy"
        '
        'mnueditpaste
        '
        Me.mnueditpaste.Name = "mnueditpaste"
        Me.mnueditpaste.Size = New System.Drawing.Size(130, 24)
        Me.mnueditpaste.Text = "paste"
        '
        'mnueditgo
        '
        Me.mnueditgo.Name = "mnueditgo"
        Me.mnueditgo.Size = New System.Drawing.Size(130, 24)
        Me.mnueditgo.Text = "go"
        '
        'mnueditback
        '
        Me.mnueditback.Name = "mnueditback"
        Me.mnueditback.Size = New System.Drawing.Size(130, 24)
        Me.mnueditback.Text = "back "
        '
        'mnueditforward
        '
        Me.mnueditforward.Name = "mnueditforward"
        Me.mnueditforward.Size = New System.Drawing.Size(130, 24)
        Me.mnueditforward.Text = "forward"
        '
        'mnuedithome
        '
        Me.mnuedithome.Name = "mnuedithome"
        Me.mnuedithome.Size = New System.Drawing.Size(130, 24)
        Me.mnuedithome.Text = "home"
        '
        'mnueditrefresh
        '
        Me.mnueditrefresh.Name = "mnueditrefresh"
        Me.mnueditrefresh.Size = New System.Drawing.Size(130, 24)
        Me.mnueditrefresh.Text = "refresh"
        '
        'mnueditstop
        '
        Me.mnueditstop.Name = "mnueditstop"
        Me.mnueditstop.Size = New System.Drawing.Size(130, 24)
        Me.mnueditstop.Text = "stop"
        '
        'mnutheme
        '
        Me.mnutheme.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuthemenormaal, Me.mnuthemerood})
        Me.mnutheme.Name = "mnutheme"
        Me.mnutheme.Size = New System.Drawing.Size(63, 24)
        Me.mnutheme.Text = "theme"
        '
        'mnuthemenormaal
        '
        Me.mnuthemenormaal.Name = "mnuthemenormaal"
        Me.mnuthemenormaal.Size = New System.Drawing.Size(133, 24)
        Me.mnuthemenormaal.Text = "normaal"
        '
        'mnuthemerood
        '
        Me.mnuthemerood.Name = "mnuthemerood"
        Me.mnuthemerood.Size = New System.Drawing.Size(133, 24)
        Me.mnuthemerood.Text = "rood"
        '
        'mnuhelp
        '
        Me.mnuhelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuhelpover})
        Me.mnuhelp.Name = "mnuhelp"
        Me.mnuhelp.Size = New System.Drawing.Size(50, 24)
        Me.mnuhelp.Text = "help"
        '
        'mnuhelpover
        '
        Me.mnuhelpover.Name = "mnuhelpover"
        Me.mnuhelpover.Size = New System.Drawing.Size(107, 24)
        Me.mnuhelpover.Text = "over"
        '
        'txtaddress
        '
        Me.txtaddress.Cursor = System.Windows.Forms.Cursors.Default
        Me.txtaddress.ForeColor = System.Drawing.Color.Black
        Me.txtaddress.Location = New System.Drawing.Point(12, 29)
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(1298, 22)
        Me.txtaddress.TabIndex = 1
        '
        'cmdgo
        '
        Me.cmdgo.AutoSize = True
        Me.cmdgo.Location = New System.Drawing.Point(1316, 27)
        Me.cmdgo.Name = "cmdgo"
        Me.cmdgo.Size = New System.Drawing.Size(81, 27)
        Me.cmdgo.TabIndex = 2
        Me.cmdgo.Text = "go"
        Me.cmdgo.UseVisualStyleBackColor = True
        '
        'cmdhome
        '
        Me.cmdhome.AutoSize = True
        Me.cmdhome.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdhome.Location = New System.Drawing.Point(99, 59)
        Me.cmdhome.Name = "cmdhome"
        Me.cmdhome.Size = New System.Drawing.Size(81, 27)
        Me.cmdhome.TabIndex = 3
        Me.cmdhome.Text = "home"
        Me.cmdhome.UseVisualStyleBackColor = True
        '
        'cmdforward
        '
        Me.cmdforward.AutoSize = True
        Me.cmdforward.Location = New System.Drawing.Point(186, 59)
        Me.cmdforward.Name = "cmdforward"
        Me.cmdforward.Size = New System.Drawing.Size(81, 27)
        Me.cmdforward.TabIndex = 4
        Me.cmdforward.Text = ">>>"
        Me.cmdforward.UseVisualStyleBackColor = True
        '
        'cmdback
        '
        Me.cmdback.AutoSize = True
        Me.cmdback.Location = New System.Drawing.Point(12, 59)
        Me.cmdback.Name = "cmdback"
        Me.cmdback.Size = New System.Drawing.Size(81, 27)
        Me.cmdback.TabIndex = 5
        Me.cmdback.Text = "<<<"
        Me.cmdback.UseVisualStyleBackColor = True
        '
        'cmdsearch
        '
        Me.cmdsearch.Location = New System.Drawing.Point(1093, 56)
        Me.cmdsearch.Name = "cmdsearch"
        Me.cmdsearch.Size = New System.Drawing.Size(81, 30)
        Me.cmdsearch.TabIndex = 6
        Me.cmdsearch.Text = "search"
        Me.cmdsearch.UseVisualStyleBackColor = True
        '
        'cmdstop
        '
        Me.cmdstop.Location = New System.Drawing.Point(1180, 57)
        Me.cmdstop.Name = "cmdstop"
        Me.cmdstop.Size = New System.Drawing.Size(81, 29)
        Me.cmdstop.TabIndex = 7
        Me.cmdstop.Text = "stop"
        Me.cmdstop.UseVisualStyleBackColor = True
        '
        'cmdrefresh
        '
        Me.cmdrefresh.Location = New System.Drawing.Point(1316, 56)
        Me.cmdrefresh.Name = "cmdrefresh"
        Me.cmdrefresh.Size = New System.Drawing.Size(81, 29)
        Me.cmdrefresh.TabIndex = 8
        Me.cmdrefresh.Text = "refresh"
        Me.cmdrefresh.UseVisualStyleBackColor = True
        '
        'txtsearch
        '
        Me.txtsearch.Location = New System.Drawing.Point(716, 57)
        Me.txtsearch.Name = "txtsearch"
        Me.txtsearch.Size = New System.Drawing.Size(371, 22)
        Me.txtsearch.TabIndex = 9
        '
        'optgoogle
        '
        Me.optgoogle.AutoSize = True
        Me.optgoogle.CheckAlign = System.Drawing.ContentAlignment.TopLeft
        Me.optgoogle.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optgoogle.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.optgoogle.Location = New System.Drawing.Point(367, 56)
        Me.optgoogle.Name = "optgoogle"
        Me.optgoogle.Size = New System.Drawing.Size(72, 21)
        Me.optgoogle.TabIndex = 10
        Me.optgoogle.TabStop = True
        Me.optgoogle.Text = "google"
        Me.optgoogle.UseVisualStyleBackColor = True
        '
        'optyoutube
        '
        Me.optyoutube.AutoSize = True
        Me.optyoutube.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.optyoutube.Location = New System.Drawing.Point(445, 56)
        Me.optyoutube.Name = "optyoutube"
        Me.optyoutube.Size = New System.Drawing.Size(80, 21)
        Me.optyoutube.TabIndex = 11
        Me.optyoutube.TabStop = True
        Me.optyoutube.Text = "youtube"
        Me.optyoutube.UseVisualStyleBackColor = True
        '
        'optfacebook
        '
        Me.optfacebook.AutoSize = True
        Me.optfacebook.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.optfacebook.Location = New System.Drawing.Point(531, 56)
        Me.optfacebook.Name = "optfacebook"
        Me.optfacebook.Size = New System.Drawing.Size(87, 21)
        Me.optfacebook.TabIndex = 12
        Me.optfacebook.TabStop = True
        Me.optfacebook.Text = "facebook"
        Me.optfacebook.UseVisualStyleBackColor = True
        '
        'opttwitter
        '
        Me.opttwitter.AutoSize = True
        Me.opttwitter.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.opttwitter.Location = New System.Drawing.Point(624, 56)
        Me.opttwitter.Name = "opttwitter"
        Me.opttwitter.Size = New System.Drawing.Size(66, 21)
        Me.opttwitter.TabIndex = 13
        Me.opttwitter.TabStop = True
        Me.opttwitter.Text = "twitter"
        Me.opttwitter.UseVisualStyleBackColor = True
        '
        'stastrip
        '
        Me.stastrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbladdress, Me.comprogressbar})
        Me.stastrip.Location = New System.Drawing.Point(0, 643)
        Me.stastrip.Name = "stastrip"
        Me.stastrip.Size = New System.Drawing.Size(1409, 25)
        Me.stastrip.TabIndex = 14
        Me.stastrip.Text = "StatusStrip1"
        '
        'lbladdress
        '
        Me.lbladdress.IsLink = True
        Me.lbladdress.LinkColor = System.Drawing.Color.Black
        Me.lbladdress.Name = "lbladdress"
        Me.lbladdress.Size = New System.Drawing.Size(77, 20)
        Me.lbladdress.Text = "lbladdress"
        '
        'comprogressbar
        '
        Me.comprogressbar.Name = "comprogressbar"
        Me.comprogressbar.Size = New System.Drawing.Size(100, 19)
        '
        'frawebbrowser
        '
        Me.frawebbrowser.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.frawebbrowser.Location = New System.Drawing.Point(0, 101)
        Me.frawebbrowser.MinimumSize = New System.Drawing.Size(20, 20)
        Me.frawebbrowser.Name = "frawebbrowser"
        Me.frawebbrowser.ScriptErrorsSuppressed = True
        Me.frawebbrowser.Size = New System.Drawing.Size(1409, 539)
        Me.frawebbrowser.TabIndex = 0
        Me.frawebbrowser.Url = New System.Uri("http://www.google.com", System.UriKind.Absolute)
        '
        'TimerURL
        '
        Me.TimerURL.Enabled = True
        Me.TimerURL.Interval = 1
        '
        'MDbrowser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(1409, 668)
        Me.Controls.Add(Me.frawebbrowser)
        Me.Controls.Add(Me.stastrip)
        Me.Controls.Add(Me.opttwitter)
        Me.Controls.Add(Me.optfacebook)
        Me.Controls.Add(Me.optyoutube)
        Me.Controls.Add(Me.optgoogle)
        Me.Controls.Add(Me.txtsearch)
        Me.Controls.Add(Me.cmdrefresh)
        Me.Controls.Add(Me.cmdstop)
        Me.Controls.Add(Me.cmdsearch)
        Me.Controls.Add(Me.cmdback)
        Me.Controls.Add(Me.cmdforward)
        Me.Controls.Add(Me.cmdhome)
        Me.Controls.Add(Me.cmdgo)
        Me.Controls.Add(Me.txtaddress)
        Me.Controls.Add(Me.mnustrip)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnustrip
        Me.Name = "MDbrowser"
        Me.Text = "MDbrowser"
        Me.WindowState = System.Windows.Forms.FormWindowState.Minimized
        Me.mnustrip.ResumeLayout(False)
        Me.mnustrip.PerformLayout()
        Me.stastrip.ResumeLayout(False)
        Me.stastrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnustrip As System.Windows.Forms.MenuStrip
    Friend WithEvents mnufile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnufileprint As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnufileprintpreview As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnufileproperties As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuedit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnueditcut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnueditcopy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnueditpaste As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnueditgo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnueditback As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnueditforward As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuedithome As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnueditrefresh As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnueditstop As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnutheme As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuthemenormaal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuthemerood As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuhelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuhelpover As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txtaddress As System.Windows.Forms.TextBox
    Friend WithEvents cmdgo As System.Windows.Forms.Button
    Friend WithEvents cmdhome As System.Windows.Forms.Button
    Friend WithEvents cmdforward As System.Windows.Forms.Button
    Friend WithEvents cmdback As System.Windows.Forms.Button
    Friend WithEvents cmdsearch As System.Windows.Forms.Button
    Friend WithEvents cmdstop As System.Windows.Forms.Button
    Friend WithEvents cmdrefresh As System.Windows.Forms.Button
    Friend WithEvents txtsearch As System.Windows.Forms.TextBox
    Friend WithEvents optgoogle As System.Windows.Forms.RadioButton
    Friend WithEvents optyoutube As System.Windows.Forms.RadioButton
    Friend WithEvents optfacebook As System.Windows.Forms.RadioButton
    Friend WithEvents opttwitter As System.Windows.Forms.RadioButton
    Friend WithEvents stastrip As System.Windows.Forms.StatusStrip
    Friend WithEvents lbladdress As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents comprogressbar As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents frawebbrowser As System.Windows.Forms.WebBrowser
    Friend WithEvents mnufileseparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnufileexit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TimerURL As System.Windows.Forms.Timer

End Class
